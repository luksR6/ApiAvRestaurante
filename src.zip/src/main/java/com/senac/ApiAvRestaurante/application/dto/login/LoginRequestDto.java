package com.senac.ApiAvRestaurante.application.dto.login;

public record LoginRequestDto(String email, String senha) {
}

