package com.senac.ApiAvRestaurante.application.dto.restaurante;

public record RestauranteRequestDto(Long id, String nome, Double mediaNota) {
}
