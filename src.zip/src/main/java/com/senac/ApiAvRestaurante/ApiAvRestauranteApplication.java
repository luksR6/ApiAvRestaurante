package com.senac.ApiAvRestaurante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiAvRestauranteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiAvRestauranteApplication.class, args);
	}

}
